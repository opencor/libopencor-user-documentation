#include <iostream>
#include <libopencor>

int main()
{
    std::cout << "Hello libOpenCOR " << libOpenCOR::versionString() << "!" << std::endl;

    return 0;
}
